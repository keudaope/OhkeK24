namespace T8
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
<<<<<<< HEAD
            Application.Run(new NumeromuunnosFM());
=======
            Application.Run(new Form1());
>>>>>>> 32f68f07ebb9734c80efaf1553139e3a984723b8
        }
    }
}